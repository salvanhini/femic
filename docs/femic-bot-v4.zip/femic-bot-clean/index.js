'use strict';
require('dotenv').config();
const path = require('path');
const fs   = require('fs/promises');

const {
  Browsers, DisconnectReason,
  fetchLatestBaileysVersion, makeWASocket, useMultiFileAuthState,
} = require('@whiskeysockets/baileys');
const pino   = require('pino');
const qrcode = require('qrcode-terminal');

const { supabase, fetchDueReminders, markReminderSent,
        updateServiceStatus, getTemplate,
        storeInboxMessage, getConversationHistory,
        cleanupOldInboxMessages } = require('./supabase');
const { detectIntent }   = require('./intent');
const { generateReply }  = require('./reply');
const { bookingFlow, jidToPhone } = require('./booking');
const { buildReminderWindow, normalizeJid, formatDate } = require('./utils');

// ─── config ──────────────────────────────────────────────────────────────────
const SVC_NAME    = process.env.WHATSAPP_SERVICE_NAME || 'baileys-main';
const AUTH_DIR    = path.join(__dirname, 'auth-' + SVC_NAME);
const CHECK_MS    = (Number(process.env.CHECK_INTERVAL_MINUTES) || 5) * 60000;
const HB_MS       = (Number(process.env.HEARTBEAT_INTERVAL_SECONDS) || 60) * 1000;
const LOGIN       = (process.env.WHATSAPP_LOGIN_METHOD || 'qr').trim();
const PAIR_PHONE  = (process.env.WHATSAPP_PAIRING_PHONE || '').replace(/\D/g, '');
const RESET       = process.env.RESET_SESSION === 'true';

// ─── state ───────────────────────────────────────────────────────────────────
let sock          = null;
let connected     = false;
let everConn      = false;
let badCount      = 0;
let schedulerOn   = false;
let heartbeatOn   = false;
let reconnTimer   = null;
let resetBusy     = false;
let lastReset     = 0;
let starting      = false;
let cleanedInbox  = false;
const seen        = new Set(); // dedup message IDs

// ─── helpers ─────────────────────────────────────────────────────────────────
const sleep = ms => new Promise(r => setTimeout(r, ms));
function tag(label, ...a) { console.log(`[${label}]`, ...a); }

function closeSock() {
  if (sock) { try { sock.end(); } catch (_) {} sock = null; }
}

// ─── reminders ───────────────────────────────────────────────────────────────
async function sendReminders() {
  if (!sock || !connected) return;
  const win   = buildReminderWindow();
  const apts  = await fetchDueReminders(win);
  if (!apts.length) { tag('Reminder', 'Nenhum lembrete.'); return; }
  tag('Reminder', apts.length + ' lembrete(s).');
  const tpl = await getTemplate();
  for (const apt of apts) {
    const p   = apt.patients;
    const jid = normalizeJid(p.whatsapp);
    if (!jid) continue;
    const msg = tpl
      .replace(/\{nome\}/g, p.name || 'Paciente')
      .replace(/\{data\}/g, formatDate(apt.appointment_date))
      .replace(/\{hora\}/g, (apt.start_time || '').slice(0, 5));
    try {
      await sock.sendMessage(jid, { text: msg });
      await markReminderSent(apt.id, 'sent');
      tag('Reminder', 'Enviado para', p.name);
    } catch (e) {
      await markReminderSent(apt.id, 'failed', e.message);
      tag('Reminder', 'Erro para', p.name, e.message);
    }
  }
}

function startScheduler() {
  if (schedulerOn) return;
  schedulerOn = true;
  setTimeout(sendReminders, 8000);
  setInterval(sendReminders, CHECK_MS);
  tag('Scheduler', 'Intervalo:', CHECK_MS / 60000 + 'min');
}

// ─── heartbeat ───────────────────────────────────────────────────────────────
function hb(status, error) {
  updateServiceStatus(SVC_NAME, status || (connected ? 'connected' : 'disconnected'), error)
    .catch(e => tag('HB', e.message));
}
function startHeartbeat() {
  if (heartbeatOn) return;
  heartbeatOn = true;
  setTimeout(() => hb(), 4000);
  setInterval(() => hb(), HB_MS);
}

// ─── reconnect ───────────────────────────────────────────────────────────────
function scheduleReconnect(ms) {
  if (reconnTimer) return;
  reconnTimer = setTimeout(() => {
    reconnTimer = null;
    startBot().catch(e => { tag('Reconn', e.message); scheduleReconnect(20000); });
  }, ms);
}

async function resetSession(reason) {
  if (resetBusy) return;
  const now = Date.now();
  if (now - lastReset < 60000) { scheduleReconnect(30000); return; }
  lastReset = now;
  resetBusy = true;
  tag('Auth', 'Resetando sessão. Motivo:', reason);
  closeSock();
  await fs.rm(AUTH_DIR, { recursive: true, force: true }).catch(() => {});
  resetBusy = false;
  scheduleReconnect(5000);
}

// ─── message handling ─────────────────────────────────────────────────────────
async function handleMessage(activeSock, msg) {
  if (msg.key.fromMe) return;
  if (msg.key.remoteJid?.endsWith('@g.us')) return;
  if (seen.has(msg.key.id)) return;
  seen.add(msg.key.id);
  setTimeout(() => seen.delete(msg.key.id), 120000);

  const text = (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption || ''
  ).trim();
  if (!text) return;

  const jid   = msg.key.remoteJid;
  const phone = jidToPhone(jid);
  tag('Msg', phone.slice(0, 6) + '***:', text.slice(0, 80));

  try { await activeSock.sendPresenceUpdate('composing', jid); } catch (_) {}

  try {
    const intent = await detectIntent(text);
    storeInboxMessage(phone, text, intent).catch(() => {});

    await sleep(1000 + Math.random() * 800);

    if (intent.category === 'agendamento' && intent.confidence >= 0.65) {
      await bookingFlow(activeSock, jid, phone, text);
    } else {
      const history = await getConversationHistory(phone, 5);
      const reply   = await generateReply(intent.category, text, history);
      if (reply) await activeSock.sendMessage(jid, { text: reply });
    }
  } catch (e) {
    tag('Msg', 'Erro:', e.message);
  } finally {
    try { await activeSock.sendPresenceUpdate('paused', jid); } catch (_) {}
  }
}

// ─── bot start ───────────────────────────────────────────────────────────────
async function startBot() {
  if (starting) return;
  starting = true;
  try {
    connected = false;
    if (RESET) {
      closeSock();
      await fs.rm(AUTH_DIR, { recursive: true, force: true }).catch(() => {});
      tag('Auth', 'RESET_SESSION executado. Remova a variável após conectar.');
    }

    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    const { version, isLatest } = await fetchLatestBaileysVersion();
    tag('Bot', 'WhatsApp Web v' + version.join('.') + (isLatest ? ' (latest)' : ''));
    closeSock();

    sock = makeWASocket({
      auth: state,
      version,
      printQRInTerminal: false,
      logger: pino({ level: 'silent' }),
      browser: Browsers.macOS('Desktop'),
      markOnlineOnConnect: true,
      syncFullHistory: false,
      connectTimeoutMs: 30000,
      retryRequestDelayMs: 2000,
      maxMsgRetryCount: 3,
    });

    // Pairing code
    if (!state.creds.registered && LOGIN === 'pairing' && PAIR_PHONE) {
      setTimeout(async () => {
        try {
          const code = await sock.requestPairingCode(PAIR_PHONE);
          console.log('\n=== CÓDIGO DE PAREAMENTO ===');
          console.log('Número: +' + PAIR_PHONE);
          console.log('Código: ' + code);
          console.log('WhatsApp → Dispositivos → Conectar com número de telefone\n');
        } catch (e) { tag('Pair', e.message); }
      }, 3000);
    }

    sock.ev.on('connection.update', async (u) => {
      if (u.qr) {
        console.log('\n=== QR CODE — escaneie no WhatsApp ===\n');
        qrcode.generate(u.qr, { small: true });
        console.log('');
      }

      if (u.connection === 'open') {
        connected = true; everConn = true; badCount = 0;
        if (reconnTimer) { clearTimeout(reconnTimer); reconnTimer = null; }
        tag('Bot', '✅ Conectado! Serviço:', SVC_NAME);
        hb('connected');
        sendReminders().catch(() => {});
      }

      if (u.connection === 'close') {
        connected = false;
        const code   = u.lastDisconnect?.error?.output?.statusCode;
        const reason = u.lastDisconnect?.error?.message || 'desconhecido';
        const logout = code === DisconnectReason.loggedOut;
        tag('Bot', 'Desconectado. Código:', code || '?', '| Motivo:', reason);

        if (!everConn && (code === 515 || code === 405)) {
          badCount++;
          if (badCount >= 2) { badCount = 0; await resetSession('bad session ' + code); }
          else await resetSession(reason);
          hb('reconnecting', reason);
          return;
        }

        if (logout) {
          hb('logged_out', reason);
          await resetSession(reason);
        } else {
          hb('reconnecting', reason);
          scheduleReconnect(10000);
        }
      }
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('messages.upsert', ({ messages }) => {
      if (!messages) return;
      for (const m of messages) handleMessage(sock, m).catch(() => {});
    });

    if (!cleanedInbox) {
      cleanedInbox = true;
      cleanupOldInboxMessages(30).catch(() => {});
    }

    startScheduler();
    startHeartbeat();
  } finally {
    starting = false;
  }
}

process.on('unhandledRejection', e => tag('Fatal', 'Unhandled:', e?.message || e));
process.on('uncaughtException',  e => tag('Fatal', 'Uncaught:',  e?.message || e));

startBot().catch(e => { console.error('[Fatal]', e); process.exit(1); });
