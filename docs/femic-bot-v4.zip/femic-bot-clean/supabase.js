'use strict';
const { createClient } = require('@supabase/supabase-js');
const WebSocket = require('ws');
const { buildReminderWindow } = require('./utils');

const url = process.env.SUPABASE_URL || process.env.FEMIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.FEMIC_SUPABASE_SERVICE_ROLE_KEY;

if (!url || !key) {
  console.error('[Supabase] SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY são obrigatórios.');
  process.exit(1);
}

const supabase = createClient(url, key, { realtime: { transport: WebSocket } });

async function fetchDueReminders(win) {
  const w = win || buildReminderWindow();
  console.log('[Supabase] Buscando:', w.targetDate, w.fromTime, '-', w.toTime);

  const { data, error } = await supabase
    .from('appointments')
    .select('id, appointment_date, start_time, status, patients(name, whatsapp)')
    .eq('appointment_date', w.targetDate)
    .in('status', ['agendado', 'confirmado'])
    .or('appointment_reminder_sent.is.false,appointment_reminder_sent.is.null,reminder_sent.is.false,reminder_sent.is.null')
    .gte('start_time', w.fromTime)
    .lte('start_time', w.toTime)
    .order('start_time');

  if (error) { console.error('[Supabase] fetchReminders:', error.message); return []; }
  return (data || []).filter(a => a.patients?.whatsapp);
}

async function markReminderSent(id, status, errMsg) {
  const ok  = status === 'sent';
  const now = new Date().toISOString();
  const { error } = await supabase.from('appointments').update({
    appointment_reminder_sent: ok,
    appointment_reminder_sent_at: ok ? now : null,
    appointment_reminder_delivery_status: status,
    appointment_reminder_error_message: errMsg || null,
    appointment_reminder_last_attempt_at: now,
    reminder_sent: ok,
    reminder_sent_at: ok ? now : null,
  }).eq('id', id);
  if (error) console.error('[Supabase] markSent:', error.message);
}

async function updateServiceStatus(name, status, errMsg) {
  const now = new Date().toISOString();
  const { error } = await supabase.from('whatsapp_service_status').upsert({
    service_name: name,
    provider: 'baileys',
    connection_status: status,
    last_seen_at: now,
    last_error: errMsg ? String(errMsg).slice(0, 500) : null,
    updated_at: now,
    ...(status === 'connected' ? { last_connected_at: now } : {}),
  }, { onConflict: 'service_name' });
  if (error) console.error('[Supabase] updateStatus:', error.message);
}

async function getTemplate() {
  const { data } = await supabase
    .from('schedule_settings')
    .select('whatsapp_template_appointment')
    .limit(1).single();
  return data?.whatsapp_template_appointment ||
    'Olá, {nome}! Lembrete da sua consulta na FEMIC: 📅 {data} ⏰ {hora}.';
}

async function storeInboxMessage(phone, text, intent) {
  const { error } = await supabase.from('whatsapp_inbox').insert({
    phone,
    message_text: text.slice(0, 2000),
    category: intent?.category || 'geral',
    confidence: intent?.confidence || 0,
    status: 'pendente',
  });
  if (error) console.error('[Supabase] storeInbox:', error.message);
}

async function getConversationHistory(phone, limit = 6) {
  const { data, error } = await supabase
    .from('whatsapp_inbox')
    .select('message_text, category, received_at')
    .eq('phone', phone.replace(/\D/g, ''))
    .order('received_at', { ascending: false })
    .limit(limit);
  if (error) { console.error('[Supabase] getHistory:', error.message); return []; }
  return data || [];
}

async function cleanupOldInboxMessages(days = 30) {
  const cutoff = new Date(Date.now() - days * 86400000).toISOString();
  const { error, count } = await supabase
    .from('whatsapp_inbox').delete({ count: 'exact' }).lt('received_at', cutoff);
  if (error) console.error('[Supabase] cleanup:', error.message);
  else console.log('[Supabase] Limpeza: removidas', count || 0, 'mensagens.');
}

module.exports = {
  supabase, fetchDueReminders, markReminderSent, updateServiceStatus,
  getTemplate, storeInboxMessage, getConversationHistory, cleanupOldInboxMessages,
};
