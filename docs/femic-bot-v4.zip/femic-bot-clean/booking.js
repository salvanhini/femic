'use strict';
const { supabase } = require('./supabase');

const URL_AGE = process.env.CAPTACAO_URL || 'https://salvanhini.github.io/agendar/';
const TG_API  = 'https://api.telegram.org/bot';
const pending = new Map();

function jidToPhone(jid) {
  return (jid || '').replace(/\D/g, '');
}

async function patientExists(phone) {
  const d = phone.replace(/\D/g, '');
  if (d.length < 10) return false;
  const last8 = d.slice(-8);
  const { data, error } = await supabase
    .from('patients').select('id')
    .or('whatsapp.eq.' + d + ',whatsapp.ilike.%' + last8)
    .limit(1);
  if (error) { console.error('[Booking] patientExists:', error.message); return false; }
  return !!(data && data.length > 0);
}

async function waitTask(phone, ms = 120000) {
  const d = phone.replace(/\D/g, '');
  const last8 = d.slice(-8);
  const end = Date.now() + ms;
  return new Promise(resolve => {
    const check = async () => {
      if (Date.now() >= end) { resolve(null); return; }
      try {
        const { data, error } = await supabase
          .from('assistant_tasks').select('id,title,patient_name,phone,notes,created_at')
          .or('phone.eq.' + d + ',phone.ilike.%' + last8)
          .eq('origin', 'captacao_publica')
          .order('created_at', { ascending: false }).limit(1);
        if (!error && data?.length > 0 && (data[0].phone || '').replace(/\D/g, '').slice(-8) === last8) {
          resolve(data[0]); return;
        }
      } catch (e) { console.error('[Booking] poll:', e.message); }
      setTimeout(check, 3000);
    };
    setTimeout(check, 3000);
  });
}

async function notifyTelegram(task, phone) {
  const token  = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return;
  const esc = s => String(s || '').replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, '\\$&');
  const text = [
    '📋 *NOVA PENDÊNCIA DE AVALIAÇÃO*',
    '━━━━━━━━━━━━━━━━━━━',
    '👤 *Nome:* ' + esc(task.patient_name || 'Não informado'),
    '📱 *WhatsApp:* ' + esc(phone || task.phone),
    '💬 *Obs:* ' + esc((task.notes || '').slice(0, 150) || 'Sem observação'),
    '━━━━━━━━━━━━━━━━━━━',
    '✅ Registrado automaticamente no sistema.',
  ].join('\n');
  try {
    await fetch(TG_API + token + '/sendMessage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: Number(chatId), text, parse_mode: 'Markdown' }),
    });
    console.log('[Telegram] Notificação enviada.');
  } catch (e) { console.error('[Telegram]', e.message); }
}

function msgWelcome() {
  return [
    'Olá! 😊 Aqui é da FEMIC Fisioterapia!',
    '',
    'Fico feliz que queira agendar uma avaliação!',
    'Para agilizar, preencha seus dados pelo link abaixo:',
    '🔗 ' + URL_AGE,
    '',
    'Assim que enviar, confirmamos o melhor horário pra você! 💙',
  ].join('\n');
}

function msgConfirmation(task) {
  return [
    'Recebemos seus dados, ' + (task?.patient_name || 'paciente') + '! ✅',
    '',
    'Sua solicitação está registrada.',
    'Em breve a equipe confirma o horário pelo WhatsApp.',
    '',
    'Qualquer dúvida é só chamar! 💙 — FEMIC Fisioterapia',
  ].join('\n');
}

async function bookingFlow(sock, jid, phone, text) {
  if (pending.has(phone)) { console.log('[Booking] Já em andamento:', phone.slice(0,6) + '***'); return; }

  const exists = await patientExists(phone);
  if (exists) { console.log('[Booking] Paciente já cadastrado:', phone.slice(0,6) + '***'); return; }

  pending.set(phone, Date.now());
  console.log('[Booking] Novo lead:', phone.slice(0,6) + '***');
  try {
    await sock.sendMessage(jid, { text: msgWelcome() });
    const task = await waitTask(phone);
    if (task) {
      console.log('[Booking] Formulário recebido! Task:', task.id);
      await sock.sendMessage(jid, { text: msgConfirmation(task) });
      notifyTelegram(task, phone).catch(() => {});
    } else {
      console.log('[Booking] Timeout. Lead não preencheu formulário:', phone.slice(0,6) + '***');
    }
  } catch (e) {
    console.error('[Booking] Erro:', e.message);
  } finally {
    pending.delete(phone);
  }
}

module.exports = { bookingFlow, jidToPhone };
